package com.ammar.ibltest.repository;

public class userRepository {
}
